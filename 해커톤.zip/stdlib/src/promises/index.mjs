import delay from "./delay.mjs";
import tick from "./tick.mjs";
import when from "./when.mjs";

export default {
  delay: delay,
  tick: tick,
  when: when
};
