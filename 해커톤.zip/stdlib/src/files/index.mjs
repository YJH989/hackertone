import buffer from "./buffer.mjs";
import text from "./text.mjs";
import url from "./url.mjs";

export default {
  buffer: buffer,
  text: text,
  url: url
};
