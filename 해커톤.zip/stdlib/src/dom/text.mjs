export default function(value) {
  return document.createTextNode(value);
}
